import { Button } from '@mui/material';
import axios from 'axios';
import React from 'react'
import { useState } from 'react';
import { useEffect } from 'react';

const CreateCoupon = () => {
  const [coupon_code, setCoupon_code] = useState("");
  const [subscription_type, setSubscription_type] = useState("");
  const [discount, setDiscount] = useState("");
  const [expiry, setExpiry] = useState("");
  const [usage_count, setUsage_count] = useState("");
  const [max_usages, setMax_usages] = useState("");


  const handleSubmit = () => {
    axios({
      method: "post",
      url: "http://localhost:5000/api/createcoupon",
      data: {
        coupon_code: coupon_code,
        subscription_type: subscription_type,
        discount: discount,
        expiration_date: expiry,
        usage_count: usage_count,
        max_usages:  max_usages,
      },
      withCredentials: true,
    })
      .then((res) => {
        console.log(res);
      })
      .catch((err) => {
        console.log(err);
      });
  }
// console.log(coupon_code)
// console.log(subscription_type)
// console.log(expiry)
// console.log(discount)
// console.log(max_usages)
// console.log(usage_count)

  return (
    <div className='create-coupon'>
    <div>
    <h3>Coupon Code</h3>
    <input value={coupon_code} onChange={(e) =>{
      setCoupon_code(e.target.value)
    }}/>
    </div>
    <div>
    <h3>Subscription Type</h3>
    <input value={subscription_type} onChange={(e) =>{
      setSubscription_type(e.target.value)
    }}/>
    </div>
    <div>
    <h3>Discount</h3>
    <input type='number' value={discount} onChange={(e) =>{
      setDiscount(e.target.value)
    }}/>
    </div>
    <div>
    <h3>Expiry Date</h3>
    <input type='date' value={expiry} onChange={(e) =>{
      setExpiry(e.target.value)
    }}/>
    </div>
    <div>
    <h3>Usage Count</h3>
    <input type='number' value={usage_count} onChange={(e) =>{
      setUsage_count(e.target.value)
    }}/>
    </div>
    <div>
    <h3>Max Usage</h3>
    <input type='number' value={max_usages} onChange={(e) =>{
      setMax_usages(e.target.value)
    }}/>
    </div>
    <Button onClick={handleSubmit} variant="contained" sx={{margin:"10px 0"}}>Submit</Button>
    </div>
  )
}

export default CreateCoupon
